default_app_config = (
    'chatterbot.ext.django_chatterbot.apps.DjangoChatterBotConfig'
)
