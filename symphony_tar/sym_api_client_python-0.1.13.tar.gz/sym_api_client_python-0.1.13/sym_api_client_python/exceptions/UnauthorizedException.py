class UnauthorizedException(Exception):
    pass
