class APIClientErrorException(Exception):
    pass
