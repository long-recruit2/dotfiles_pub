class ServerErrorException(Exception):
    pass
